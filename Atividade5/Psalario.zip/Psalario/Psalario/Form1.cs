﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace Psalario
{
    public partial class Form1 : Form
    {
        int NumFilhos;
        double SalBruto, SalFamilia, SalLiquido, DescInss, DescIrpf;

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
                Close();
        }

        private void btnDesconto_Click(object sender, EventArgs e)
        {
            SalLiquido = 0;
            //Calculo INSS
            if(SalBruto<=800.47)
            {
                txtAliqInss.Text = "7,65%";
                DescInss =SalBruto * 0.0765;
            }
            else if(SalBruto<1050)
            {
                txtAliqInss.Text = "8,65%";
                DescInss = SalBruto * 0.0865;
            }
            else if(SalBruto<1400.77)
            {
                txtAliqInss.Text = "9,00%";
                DescInss = SalBruto * 0.09;
            }
            else if(SalBruto<2801.56)
            {
                txtAliqInss.Text = "11,00%";
                DescInss = SalBruto * 0.11;
            }
            else
            {
                txtAliqInss.Text = "Teto";
                DescInss = 308.17;
            }

            //Calculo IRPF
            if(SalBruto<1257.12)
            {
                txtAliqIrpf.Text = "Isento";
                DescIrpf = 0;
            }
            else if(SalBruto<2512.08)
            {
                txtAliqIrpf.Text = "15,00%";
                DescIrpf = SalBruto * 0.15;
            }
            else
            {
                txtAliqIrpf.Text = "27,50%";
                DescIrpf = SalBruto * 0.275;
            }

            //Calculo Salário Família
            if (NumFilhos == 0 || SalBruto > 654.61)
                SalFamilia = 0;
            else if (SalBruto < 435.52)
            {
                SalFamilia = NumFilhos * 22.33;
            }
            else
            {
                SalFamilia = NumFilhos * 15.74;
            }

            SalLiquido = SalBruto - (DescInss + DescIrpf) + SalFamilia;

            txtDescInss.Text = DescInss.ToString("N2");
            txtDescIrpf.Text = DescIrpf.ToString("N2");
            txtSalFamilia.Text = SalFamilia.ToString("N2");
            txtSalLiquido.Text = SalLiquido.ToString("N2");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            mskbxSalBruto.ValidatingType = typeof(System.ComponentModel.DecimalConverter);
        }

        private void mskbxNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && e.KeyChar != ' ' && e.KeyChar != (char)8)
            {
                e.Handled = true;
                MessageBox.Show("Caracter inválido!");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            NumFilhos = 0;
            SalBruto = 0;
            SalFamilia = 0;
            SalLiquido = 0;
            DescInss = 0;
            DescIrpf = 0;
            mskbxNome.Clear();
            mskbxSalBruto.Clear();
            mskbxFilhos.Clear();
            txtAliqInss.Clear();
            txtAliqIrpf.Clear();
            txtDescInss.Clear();
            txtDescIrpf.Clear();
            txtSalFamilia.Clear();
            txtSalLiquido.Clear();
            errorProvider1.Clear();
            errorProvider2.Clear();
        }

        private void mskbxFilhos_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(mskbxFilhos, "");
            if (!Int32.TryParse(mskbxFilhos.Text, out NumFilhos))
            {
                errorProvider2.SetError(mskbxFilhos, "Número de filhos inválido!");
                mskbxFilhos.Focus();
            }
        }

        private void mskbxSalBruto_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(mskbxSalBruto, "");
            if (!Double.TryParse(mskbxSalBruto.Text, out SalBruto))
            {
                errorProvider1.SetError(mskbxSalBruto, "Valor de salário inválido!");
                mskbxSalBruto.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
