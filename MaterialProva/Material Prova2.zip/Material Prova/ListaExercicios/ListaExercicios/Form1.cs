﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace ListaExercicios
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exc36ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void exc37ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            double[] VetA = new double[10];
            double[] VetB = new double[10];
            string auxiliar1 = "";
            string auxiliar2 = "";
            int z = 0;

            for (var x=0; x<10; x++)
            {
                auxiliar1 = Interaction.InputBox($"Digite o {x + 1}º número: ", "Entrada de Dados");
                if(!Double.TryParse(auxiliar1, out VetA[x]))
                {
                    MessageBox.Show("Somente valores numéricos são permitidos!");
                }
                if(VetA[x] <= 0)
                {
                    MessageBox.Show("Utilize somente números maiores que 0!");
                    x--;
                }
            }

            auxiliar1 = "";

            foreach (var i in VetA)
            {
                if (i % 2 == 0)
                    VetB[z] = i * 5;
                else
                    VetB[z] = i + 5;
                auxiliar2 += $"VetB[{z + 1}]: {VetB[z]}\n";
                z++;
            }
            auxiliar1 = "";
            z = 0;
            foreach (var y in VetA)
            {
                auxiliar1 += $"VetA[{z + 1}]: {y}\n";
                z++;
            }
            MessageBox.Show($"Números digitados:\n" +
                $"{auxiliar1}" + "\n\n" + 
                $"Resultado:\n{auxiliar2}");
        }

        private void exc38ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            double[,] Compras = new double[5, 7];
            double[] TotalDia = new double[5];
            double TotalGeral;
            string auxiliar = "";

            for(var x=0; x<5; x++)
            {
                for(var y=0; y<7; y++)
                {
                    auxiliar = Interaction.InputBox($"Digite o item {y + 1} do dia {x + 1}");
                    if (!Double.TryParse(auxiliar, out Compras[x, y]))
                    {
                        MessageBox.Show("Digite apenas valores numéricos!");
                        y--;
                    }
                    else if (Compras[x,y] < 0)
                    {
                        MessageBox.Show("Digite apenas valores maiores que zero!");
                        y--;
                    }
                    TotalDia[x] += Compras[x, y];
                }
            }
            auxiliar = "";
            for (var i = 0; i < 5; i++)
                auxiliar += $"Total dia {i + 1}: {TotalDia[i]}\n";
            MessageBox.Show(auxiliar);
        }


        private void exc39ToolStripMenuItem_Click(object sender, EventArgs e)
        {
         
        }

        private void exc40ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<Exerc40>().Count() > 0)
            {
                MessageBox.Show("Formulario já existe!");
                Application.OpenForms["Exerc40"].BringToFront();
            }
            else
            {
                Exerc40 Obj1 = new Exerc40();
                Obj1.MdiParent = this;
                Obj1.WindowState = FormWindowState.Maximized;
                Obj1.Show();
            }
        }
    }
}
