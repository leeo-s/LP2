﻿
namespace ListaExercicios
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exc36ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exc37ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exc38ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exc39ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exc40ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lstbxExc38 = new System.Windows.Forms.ListBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exc36ToolStripMenuItem,
            this.exc37ToolStripMenuItem,
            this.exc38ToolStripMenuItem,
            this.exc39ToolStripMenuItem,
            this.exc40ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // exc36ToolStripMenuItem
            // 
            this.exc36ToolStripMenuItem.Name = "exc36ToolStripMenuItem";
            this.exc36ToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.exc36ToolStripMenuItem.Text = "Exc 36";
            this.exc36ToolStripMenuItem.Click += new System.EventHandler(this.exc36ToolStripMenuItem_Click);
            // 
            // exc37ToolStripMenuItem
            // 
            this.exc37ToolStripMenuItem.Name = "exc37ToolStripMenuItem";
            this.exc37ToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.exc37ToolStripMenuItem.Text = "Exc 37";
            this.exc37ToolStripMenuItem.Click += new System.EventHandler(this.exc37ToolStripMenuItem_Click);
            // 
            // exc38ToolStripMenuItem
            // 
            this.exc38ToolStripMenuItem.Name = "exc38ToolStripMenuItem";
            this.exc38ToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.exc38ToolStripMenuItem.Text = "Exc 38";
            this.exc38ToolStripMenuItem.Click += new System.EventHandler(this.exc38ToolStripMenuItem_Click);
            // 
            // exc39ToolStripMenuItem
            // 
            this.exc39ToolStripMenuItem.Name = "exc39ToolStripMenuItem";
            this.exc39ToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.exc39ToolStripMenuItem.Text = "Exc 39";
            this.exc39ToolStripMenuItem.Click += new System.EventHandler(this.exc39ToolStripMenuItem_Click);
            // 
            // exc40ToolStripMenuItem
            // 
            this.exc40ToolStripMenuItem.Name = "exc40ToolStripMenuItem";
            this.exc40ToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.exc40ToolStripMenuItem.Text = "Exc40";
            this.exc40ToolStripMenuItem.Click += new System.EventHandler(this.exc40ToolStripMenuItem_Click);
            // 
            // lstbxExc38
            // 
            this.lstbxExc38.FormattingEnabled = true;
            this.lstbxExc38.Location = new System.Drawing.Point(258, 113);
            this.lstbxExc38.Name = "lstbxExc38";
            this.lstbxExc38.Size = new System.Drawing.Size(120, 95);
            this.lstbxExc38.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lstbxExc38);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exc36ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exc37ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exc38ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exc39ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exc40ToolStripMenuItem;
        private System.Windows.Forms.ListBox lstbxExc38;
    }
}

