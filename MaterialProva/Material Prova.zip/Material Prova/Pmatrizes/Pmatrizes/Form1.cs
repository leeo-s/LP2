﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ArrayList Alunos = new ArrayList();
            string auxiliar;

            Alunos.Add("Ana");
            Alunos.Add("André");
            Alunos.Add("Débora");
            Alunos.Add("Fátima");
            Alunos.Add("João");
            Alunos.Add("Janete");
            Alunos.Add("Otávio");
            Alunos.Add("Marcelo");
            Alunos.Add("Pedro");
            Alunos.Add("Thais");

            auxiliar = "COM O OTÁVIO:" + "\n\n";
            foreach (var x in Alunos)
                auxiliar += x.ToString() + "\n";
            MessageBox.Show(auxiliar, "Lista sem a remoção");


            Alunos.Remove("Otávio");

            auxiliar = "SEM O OTÁVIO:" + "\n\n";
            foreach (var x in Alunos)
                auxiliar += x.ToString() + "\n";
            MessageBox.Show(auxiliar, "Lista com a remoção");
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "Andre", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;

            for (I = 0; I < N - 1; I++)
                Total += Alunos[I].Length;
            MessageBox.Show(Total.ToString());
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double[] media = new double[20];
            string auxiliar = "";

            for (var x = 0; x < 20; x++)
            {
                for (var y = 0; y < 3; y++)
                {
                    auxiliar = Interaction.InputBox($"Digite a Nota {y + 1} do Aluno {x + 1}", "Entrada de Dados");
                    if (auxiliar == "" || auxiliar == " ")
                    {
                        MessageBox.Show("Valores em branco não são permitidos");
                        return;
                    }
                    if (!Double.TryParse(auxiliar, out notas[x, y]))
                    {
                        MessageBox.Show("Valor não numérico!");
                        y--;
                    }
                    else if (notas[x, y] < 0 || notas[x, y] > 10)
                    {
                        MessageBox.Show("Valor maior que 10 ou menor que 0");
                        y--;
                    }
                    else
                        media[x] += notas[x, y];
                }
                media[x] = media[x] / 3;
            }

            auxiliar = "";
            for (var z = 0; z < 20; z++)
            {
                auxiliar += $"Média do Aluno {z + 1}: {media[z]}\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite um Número({i + 1}):", "Entrada de Dados");
                if (auxiliar == "")
                    return;
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido!");
                    i--;
                }
                else
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }
            MessageBox.Show(saida);
            //reverse
            //Array.Reverse(vetor);
            //auxiliar = "";
            //foreach (var x in vetor)
            //    auxiliar += x + " ";
            //MessageBox.Show(auxiliar);

            //for ao contrário
            //auxiliar = "";
            //for (var y = 19; y >= 0; y--)
            //    auxiliar += vetor[y] + "\n";
            //MessageBox.Show(auxiliar);
        }

        private void exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Formulario já existe!");
                Application.OpenForms["frmExercicio5"].BringToFront();
            }
            else
            {
                frmExercicio5 Obj1 = new frmExercicio5();
                Obj1.MdiParent = this;
                Obj1.WindowState = FormWindowState.Maximized;
                Obj1.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
