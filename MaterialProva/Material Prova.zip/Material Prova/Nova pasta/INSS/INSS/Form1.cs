﻿using System;
using System.Windows.Forms;

namespace INSS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVer_Click(object sender, EventArgs e)
        {
           
                if (double.TryParse(MskTxtSalBru.Text, out double SalarioBruto)
                    && double.TryParse(MskTxtFilhos.Text, out double numeroFilhos)
                    && MskTxtNome.Text != "")
            {
                    double salarioFamilia = 0.0;

                    TxtAliqINSS.Text = "0.0";
                    TxtAliqIRPF.Text = "0.0";


                if (SalarioBruto > 2801.56)
                    {
                        TxtDescINSS.Text = (308.17).ToString();
                }
                    else if (SalarioBruto >= 1400.78 && SalarioBruto <= 2801.56)
                    {
                        TxtAliqINSS.Text = (11.00).ToString();
                        TxtDescINSS.Text = (Convert.ToDouble(TxtAliqINSS.Text) * SalarioBruto / 100.00).ToString();
                }
                    else if (SalarioBruto >= 1050.01 && SalarioBruto < 1400.78)
                    {
                        TxtAliqINSS.Text = (9.00).ToString();
                        TxtDescINSS.Text = (Convert.ToDouble(TxtAliqINSS.Text) * SalarioBruto / 100.00).ToString();
                    }
                    else if (SalarioBruto >= 800.48 && SalarioBruto < 1050.01)
                    {
                        TxtAliqINSS.Text = (8.65).ToString();
                        TxtDescINSS.Text = (Convert.ToDouble(TxtAliqINSS.Text) * SalarioBruto / 100.00).ToString();
                    }
                    else
                    {
                        TxtAliqINSS.Text = (7.65).ToString();
                        TxtDescINSS.Text = (Convert.ToDouble(TxtAliqINSS.Text) * SalarioBruto / 100.00).ToString();
                    }



                    if (SalarioBruto > 2512.08)
                    {
                        TxtAliqIRPF.Text = (27.5).ToString();
                        TxtDescIRPF.Text = (Convert.ToDouble(TxtAliqIRPF.Text) * SalarioBruto / 100.00).ToString();

                    }
                    else if (SalarioBruto >= 1257.13 && SalarioBruto <= 2512.08)
                    {
                        TxtAliqIRPF.Text = (15.00).ToString();
                        TxtDescIRPF.Text = (Convert.ToDouble(TxtAliqIRPF.Text) * SalarioBruto / 100.00).ToString();
                    }
                    else
                    {
                        TxtAliqIRPF.Text = (0.00).ToString();
                        TxtDescIRPF.Text = ((Convert.ToDouble(TxtAliqIRPF.Text)) * SalarioBruto / 100.00).ToString();
                    }


                    if (SalarioBruto > 654.61)
                    {
                        salarioFamilia = 0.0;
                    }
                    else if (SalarioBruto >= 435.53 && SalarioBruto <= 654.61)
                    {
                        salarioFamilia = numeroFilhos * 15.74;
                    }
                    else
                    {
                        salarioFamilia = numeroFilhos * 22.33;
                    }


                    MskTxtSalBru.Text = (SalarioBruto - Convert.ToDouble(TxtDescINSS.Text) - Convert.ToDouble(TxtDescIRPF.Text) + salarioFamilia).ToString();
                    TxtAliqINSS.Text = TxtAliqINSS.Text + " %";
                    TxtAliqIRPF.Text = TxtAliqIRPF.Text + " %";




                }
                else
                {
                    MessageBox.Show("Ixi, tem algo errado aí, verifique os valores inseridos.");
                }








            }

        private void somente_Numeros(object sender, KeyPressEventArgs e)
        {
            //Verifica se não é tecla de controle, decimal, "." e ","
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != ',')
            {
                e.Handled = true;
            }
        }

        private void txtSalarioBruto_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void txtNomeFuncionario_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
        }
    
