﻿
namespace INSS
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnVer = new System.Windows.Forms.Button();
            this.LblNome = new System.Windows.Forms.Label();
            this.LblSalBru = new System.Windows.Forms.Label();
            this.LblFilhos = new System.Windows.Forms.Label();
            this.LblAliqINSS = new System.Windows.Forms.Label();
            this.LblAliqIRPF = new System.Windows.Forms.Label();
            this.LblSalFam = new System.Windows.Forms.Label();
            this.LblSalLiq = new System.Windows.Forms.Label();
            this.LblDescINSS = new System.Windows.Forms.Label();
            this.LblDescIRPF = new System.Windows.Forms.Label();
            this.TxtSalFam = new System.Windows.Forms.TextBox();
            this.TxtAliqIRPF = new System.Windows.Forms.TextBox();
            this.TxtAliqINSS = new System.Windows.Forms.TextBox();
            this.TxtSalLiq = new System.Windows.Forms.TextBox();
            this.TxtDescINSS = new System.Windows.Forms.TextBox();
            this.TxtDescIRPF = new System.Windows.Forms.TextBox();
            this.MskTxtNome = new System.Windows.Forms.MaskedTextBox();
            this.MskTxtSalBru = new System.Windows.Forms.MaskedTextBox();
            this.MskTxtFilhos = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // BtnVer
            // 
            this.BtnVer.AutoSize = true;
            this.BtnVer.Font = new System.Drawing.Font("Gadugi", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnVer.Location = new System.Drawing.Point(296, 190);
            this.BtnVer.Name = "BtnVer";
            this.BtnVer.Size = new System.Drawing.Size(192, 35);
            this.BtnVer.TabIndex = 4;
            this.BtnVer.Text = "Verificar Desconto";
            this.BtnVer.UseVisualStyleBackColor = true;
            this.BtnVer.Click += new System.EventHandler(this.BtnVer_Click);
            // 
            // LblNome
            // 
            this.LblNome.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.LblNome.AutoSize = true;
            this.LblNome.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblNome.Location = new System.Drawing.Point(39, 32);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(193, 22);
            this.LblNome.TabIndex = 1;
            this.LblNome.Text = "Nome do Funcionário";
            // 
            // LblSalBru
            // 
            this.LblSalBru.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.LblSalBru.AutoSize = true;
            this.LblSalBru.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblSalBru.Location = new System.Drawing.Point(39, 81);
            this.LblSalBru.Name = "LblSalBru";
            this.LblSalBru.Size = new System.Drawing.Size(119, 22);
            this.LblSalBru.TabIndex = 2;
            this.LblSalBru.Text = "Salário Bruto";
            // 
            // LblFilhos
            // 
            this.LblFilhos.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.LblFilhos.AutoSize = true;
            this.LblFilhos.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblFilhos.Location = new System.Drawing.Point(39, 131);
            this.LblFilhos.Name = "LblFilhos";
            this.LblFilhos.Size = new System.Drawing.Size(159, 22);
            this.LblFilhos.TabIndex = 3;
            this.LblFilhos.Text = "Número de Filhos";
            // 
            // LblAliqINSS
            // 
            this.LblAliqINSS.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.LblAliqINSS.AutoSize = true;
            this.LblAliqINSS.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblAliqINSS.Location = new System.Drawing.Point(39, 252);
            this.LblAliqINSS.Name = "LblAliqINSS";
            this.LblAliqINSS.Size = new System.Drawing.Size(125, 22);
            this.LblAliqINSS.TabIndex = 4;
            this.LblAliqINSS.Text = "Aliquota INSS";
            // 
            // LblAliqIRPF
            // 
            this.LblAliqIRPF.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.LblAliqIRPF.AutoSize = true;
            this.LblAliqIRPF.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblAliqIRPF.Location = new System.Drawing.Point(39, 296);
            this.LblAliqIRPF.Name = "LblAliqIRPF";
            this.LblAliqIRPF.Size = new System.Drawing.Size(122, 22);
            this.LblAliqIRPF.TabIndex = 5;
            this.LblAliqIRPF.Text = "Aliquota IRPF";
            // 
            // LblSalFam
            // 
            this.LblSalFam.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.LblSalFam.AutoSize = true;
            this.LblSalFam.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblSalFam.Location = new System.Drawing.Point(39, 340);
            this.LblSalFam.Name = "LblSalFam";
            this.LblSalFam.Size = new System.Drawing.Size(159, 22);
            this.LblSalFam.TabIndex = 6;
            this.LblSalFam.Text = "Salário da Família";
            // 
            // LblSalLiq
            // 
            this.LblSalLiq.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.LblSalLiq.AutoSize = true;
            this.LblSalLiq.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblSalLiq.Location = new System.Drawing.Point(39, 384);
            this.LblSalLiq.Name = "LblSalLiq";
            this.LblSalLiq.Size = new System.Drawing.Size(136, 22);
            this.LblSalLiq.TabIndex = 7;
            this.LblSalLiq.Text = "Salário Liquido";
            // 
            // LblDescINSS
            // 
            this.LblDescINSS.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.LblDescINSS.AutoSize = true;
            this.LblDescINSS.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDescINSS.Location = new System.Drawing.Point(452, 252);
            this.LblDescINSS.Name = "LblDescINSS";
            this.LblDescINSS.Size = new System.Drawing.Size(133, 22);
            this.LblDescINSS.TabIndex = 8;
            this.LblDescINSS.Text = "Desconto INSS";
            // 
            // LblDescIRPF
            // 
            this.LblDescIRPF.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.LblDescIRPF.AutoSize = true;
            this.LblDescIRPF.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblDescIRPF.Location = new System.Drawing.Point(452, 296);
            this.LblDescIRPF.Name = "LblDescIRPF";
            this.LblDescIRPF.Size = new System.Drawing.Size(130, 22);
            this.LblDescIRPF.TabIndex = 9;
            this.LblDescIRPF.Text = "Desconto IRPF";
            // 
            // TxtSalFam
            // 
            this.TxtSalFam.Enabled = false;
            this.TxtSalFam.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtSalFam.Location = new System.Drawing.Point(228, 337);
            this.TxtSalFam.Name = "TxtSalFam";
            this.TxtSalFam.Size = new System.Drawing.Size(198, 33);
            this.TxtSalFam.TabIndex = 7;
            // 
            // TxtAliqIRPF
            // 
            this.TxtAliqIRPF.Enabled = false;
            this.TxtAliqIRPF.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtAliqIRPF.Location = new System.Drawing.Point(228, 293);
            this.TxtAliqIRPF.Name = "TxtAliqIRPF";
            this.TxtAliqIRPF.Size = new System.Drawing.Size(198, 33);
            this.TxtAliqIRPF.TabIndex = 6;
            // 
            // TxtAliqINSS
            // 
            this.TxtAliqINSS.Enabled = false;
            this.TxtAliqINSS.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtAliqINSS.Location = new System.Drawing.Point(228, 241);
            this.TxtAliqINSS.Name = "TxtAliqINSS";
            this.TxtAliqINSS.Size = new System.Drawing.Size(198, 33);
            this.TxtAliqINSS.TabIndex = 5;
            // 
            // TxtSalLiq
            // 
            this.TxtSalLiq.Enabled = false;
            this.TxtSalLiq.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtSalLiq.Location = new System.Drawing.Point(228, 384);
            this.TxtSalLiq.Name = "TxtSalLiq";
            this.TxtSalLiq.Size = new System.Drawing.Size(198, 33);
            this.TxtSalLiq.TabIndex = 16;
            // 
            // TxtDescINSS
            // 
            this.TxtDescINSS.Enabled = false;
            this.TxtDescINSS.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDescINSS.Location = new System.Drawing.Point(591, 241);
            this.TxtDescINSS.Name = "TxtDescINSS";
            this.TxtDescINSS.Size = new System.Drawing.Size(185, 33);
            this.TxtDescINSS.TabIndex = 8;
            // 
            // TxtDescIRPF
            // 
            this.TxtDescIRPF.Enabled = false;
            this.TxtDescIRPF.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtDescIRPF.Location = new System.Drawing.Point(591, 293);
            this.TxtDescIRPF.Name = "TxtDescIRPF";
            this.TxtDescIRPF.Size = new System.Drawing.Size(185, 33);
            this.TxtDescIRPF.TabIndex = 9;
            // 
            // MskTxtNome
            // 
            this.MskTxtNome.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MskTxtNome.Location = new System.Drawing.Point(255, 29);
            this.MskTxtNome.Name = "MskTxtNome";
            this.MskTxtNome.Size = new System.Drawing.Size(391, 33);
            this.MskTxtNome.TabIndex = 1;
            // 
            // MskTxtSalBru
            // 
            this.MskTxtSalBru.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MskTxtSalBru.Location = new System.Drawing.Point(255, 78);
            this.MskTxtSalBru.Mask = "9999,9";
            this.MskTxtSalBru.Name = "MskTxtSalBru";
            this.MskTxtSalBru.Size = new System.Drawing.Size(391, 33);
            this.MskTxtSalBru.TabIndex = 2;
            this.MskTxtSalBru.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MskTxtFilhos
            // 
            this.MskTxtFilhos.Font = new System.Drawing.Font("Gadugi", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MskTxtFilhos.Location = new System.Drawing.Point(255, 131);
            this.MskTxtFilhos.Name = "MskTxtFilhos";
            this.MskTxtFilhos.Size = new System.Drawing.Size(391, 33);
            this.MskTxtFilhos.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.MskTxtFilhos);
            this.Controls.Add(this.MskTxtSalBru);
            this.Controls.Add(this.MskTxtNome);
            this.Controls.Add(this.TxtDescIRPF);
            this.Controls.Add(this.TxtDescINSS);
            this.Controls.Add(this.TxtSalLiq);
            this.Controls.Add(this.TxtAliqINSS);
            this.Controls.Add(this.TxtAliqIRPF);
            this.Controls.Add(this.TxtSalFam);
            this.Controls.Add(this.LblDescIRPF);
            this.Controls.Add(this.LblDescINSS);
            this.Controls.Add(this.LblSalLiq);
            this.Controls.Add(this.LblSalFam);
            this.Controls.Add(this.LblAliqIRPF);
            this.Controls.Add(this.LblAliqINSS);
            this.Controls.Add(this.LblFilhos);
            this.Controls.Add(this.LblSalBru);
            this.Controls.Add(this.LblNome);
            this.Controls.Add(this.BtnVer);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnVer;
        private System.Windows.Forms.Label LblNome;
        private System.Windows.Forms.Label LblSalBru;
        private System.Windows.Forms.Label LblFilhos;
        private System.Windows.Forms.Label LblAliqINSS;
        private System.Windows.Forms.Label LblAliqIRPF;
        private System.Windows.Forms.Label LblSalFam;
        private System.Windows.Forms.Label LblSalLiq;
        private System.Windows.Forms.Label LblDescINSS;
        private System.Windows.Forms.Label LblDescIRPF;
        private System.Windows.Forms.TextBox TxtSalFam;
        private System.Windows.Forms.TextBox TxtAliqIRPF;
        private System.Windows.Forms.TextBox TxtAliqINSS;
        private System.Windows.Forms.TextBox TxtSalLiq;
        private System.Windows.Forms.TextBox TxtDescINSS;
        private System.Windows.Forms.TextBox TxtDescIRPF;
        private System.Windows.Forms.MaskedTextBox MskTxtNome;
        private System.Windows.Forms.MaskedTextBox MskTxtSalBru;
        private System.Windows.Forms.MaskedTextBox MskTxtFilhos;
    }
}

