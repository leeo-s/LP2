﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;

        private void TxtLadoB_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtLadoB, "");
            if (!Double.TryParse(txtLadoB.Text, out LadoB))
            {
                errorProvider1.SetError(txtLadoB, "Valor de B inválido!");
                txtLadoA.Focus();
            }
        }

        private void TxtLadoC_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtLadoC, "");
            if (!Double.TryParse(txtLadoC.Text, out LadoC))
            {
                errorProvider1.SetError(txtLadoC, "Valor de C inválido!");
                txtLadoA.Focus();
            }
        }

        private void BtnEnviar_Click(object sender, EventArgs e)
        {
            if(LadoA < (LadoB + LadoC) && LadoA > 
                Math.Abs(LadoB - LadoC) && LadoB < (LadoA + LadoC)
                && LadoB > Math.Abs(LadoA - LadoC)
                && LadoC < (LadoA + LadoB) &&
                LadoC > Math.Abs(LadoA - LadoB))
            {
                if(LadoA==LadoB && LadoB==LadoC)
                    MessageBox.Show($"Os valores {LadoA}, {LadoB} e {LadoC} formam um triângulo equilátero");
                else
                {
                    if (LadoA==LadoB || LadoA==LadoC || LadoB==LadoC)
                        MessageBox.Show($"Os valores de {LadoA}, {LadoB} e {LadoC} formam um triângulo isósceles");
                    else
                    {
                        MessageBox.Show($"Os valores de {LadoA}, {LadoB} e {LadoC} formam um triângulo escaleno");
                    }
                }
            }
            else
                MessageBox.Show("Não é um triângulo");
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
            errorProvider1.Clear();
            errorProvider2.Clear();
            errorProvider3.Clear();
            LadoA = 0;
            LadoB = 0;
            LadoC = 0;
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
                Close();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtLadoA, "");
            if (!Double.TryParse(txtLadoA.Text, out LadoA))
            {
                errorProvider1.SetError(txtLadoA, "Valor de A inválido!");
                txtLadoA.Focus();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
