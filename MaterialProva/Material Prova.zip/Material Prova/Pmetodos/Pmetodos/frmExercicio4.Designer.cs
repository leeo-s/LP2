﻿
namespace Pmetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContaLetras = new System.Windows.Forms.Button();
            this.btnPosicao = new System.Windows.Forms.Button();
            this.btnNumeros = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richtxtFrase
            // 
            this.richtxtFrase.Location = new System.Drawing.Point(183, 27);
            this.richtxtFrase.Name = "richtxtFrase";
            this.richtxtFrase.Size = new System.Drawing.Size(379, 224);
            this.richtxtFrase.TabIndex = 0;
            this.richtxtFrase.Text = "Digite um texto...";
            // 
            // btnContaLetras
            // 
            this.btnContaLetras.Location = new System.Drawing.Point(446, 257);
            this.btnContaLetras.Name = "btnContaLetras";
            this.btnContaLetras.Size = new System.Drawing.Size(116, 38);
            this.btnContaLetras.TabIndex = 13;
            this.btnContaLetras.Text = "Contar Letras";
            this.btnContaLetras.UseVisualStyleBackColor = true;
            this.btnContaLetras.Click += new System.EventHandler(this.btnContaLetras_Click);
            // 
            // btnPosicao
            // 
            this.btnPosicao.Location = new System.Drawing.Point(315, 257);
            this.btnPosicao.Name = "btnPosicao";
            this.btnPosicao.Size = new System.Drawing.Size(116, 38);
            this.btnPosicao.TabIndex = 12;
            this.btnPosicao.Text = "Posição 1º Caracter em Branco";
            this.btnPosicao.UseVisualStyleBackColor = true;
            this.btnPosicao.Click += new System.EventHandler(this.btnPosicao_Click);
            // 
            // btnNumeros
            // 
            this.btnNumeros.Location = new System.Drawing.Point(183, 257);
            this.btnNumeros.Name = "btnNumeros";
            this.btnNumeros.Size = new System.Drawing.Size(116, 38);
            this.btnNumeros.TabIndex = 11;
            this.btnNumeros.Text = "Contar Números";
            this.btnNumeros.UseVisualStyleBackColor = true;
            this.btnNumeros.Click += new System.EventHandler(this.btnNumeros_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(183, 301);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(379, 23);
            this.btnLimpar.TabIndex = 14;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnContaLetras);
            this.Controls.Add(this.btnPosicao);
            this.Controls.Add(this.btnNumeros);
            this.Controls.Add(this.richtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richtxtFrase;
        private System.Windows.Forms.Button btnContaLetras;
        private System.Windows.Forms.Button btnPosicao;
        private System.Windows.Forms.Button btnNumeros;
        private System.Windows.Forms.Button btnLimpar;
    }
}