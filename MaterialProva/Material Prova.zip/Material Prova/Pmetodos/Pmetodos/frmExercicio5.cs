﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
        }

        private void btnSorteio_Click(object sender, EventArgs e)
        {
            int numero1, numero2;

            if(!int.TryParse(txtNum1.Text, out numero1) || !int.TryParse(txtNum2.Text, out numero2))
                MessageBox.Show("Digite apenas números!");
            else
                if((numero1<=0) || (numero2<=0) || (numero1>=numero2))
                {
                MessageBox.Show("O numero 1 deve ser menor que o número 2 OU não podem ter números menores ou iguais a zero!");
                }
                else
                {
                Random objR = new Random();
                int aleatorio = objR.Next(numero1, numero2+1);//retorna número randômico
                MessageBox.Show($"O número sorteado foi o {aleatorio}");
            }
                
        }
    }
}
