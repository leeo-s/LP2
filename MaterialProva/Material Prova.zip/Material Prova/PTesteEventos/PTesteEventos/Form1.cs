﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteEventos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //mascara
            mskbxSalario.Mask = "$9,999.99";
            //permitir valores numericos e decimais
            mskbxSalario.ValidatingType = typeof(System.ComponentModel.DecimalConverter);
            mskbxSalario.PromptChar = ' ';
            mskbxSalario.TextAlign = HorizontalAlignment.Left;
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            Char[] Numeros = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
            bool TemNumero1 = txtNome.Text.Any(c => Numeros.Contains(c));
            if (TemNumero1)
                MessageBox.Show("Não pode ter números!");
        }

        private void txtEndereco_Validating(object sender, CancelEventArgs e)
        {
            if (txtEndereco.Text=="")
            {
                MessageBox.Show("Endereço inválido!");
                e.Cancel = true;
            }
        }

        private void txtEmail_Validated(object sender, EventArgs e)
        {
            if (txtEmail.Text=="")
            {
                MessageBox.Show("E-mail inválido!");
                txtEmail.Focus();
            }
        }

        private void mskbxData_Validated(object sender, EventArgs e)
        {
            DateTime dtNasc;

            if (!DateTime.TryParse(mskbxData.Text, out dtNasc))
            {
                MessageBox.Show("Data Inválida!");
                mskbxData.Focus();
            }
            else
                MessageBox.Show("A data é: " + dtNasc.ToShortDateString());

        }

        private void mskbxSalario_Leave(object sender, EventArgs e)
        {
            MessageBox.Show("Salario perde o foco");
        }

        private void btnEnviar_Enter(object sender, EventArgs e)
        {
            MessageBox.Show("Botão recebendo o foco");
        }
    }
}
