﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            string auxiliar2 = "";
            double[,] Vendas = new double[4, 4];
            double TotalMes=0;
            double TotalGeral=0;

            for(var i=0; i<4; i++)
            {
                for(var j=0; j<4; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite o total da semana {j + 1} do mês {i+1}:", "Vendas Mensais");
                    if (!Double.TryParse(auxiliar, out Vendas[i, j]))
                    {
                        MessageBox.Show("Digite apenas valores numéricos!");
                        j--;
                    }
                    else if (Vendas[i, j] < 0)
                    {
                        MessageBox.Show("Digite apenas valores maiores ou iguais a zero!");
                        j--;
                    }
                    else
                    {
                        TotalMes += Vendas[i, j];
                        lstbxVendas.Items.Add($"Total do mês {i + 1}, Semana {j + 1}: {Vendas[i, j].ToString("N2")}");
                    }
                }
                lstbxVendas.Items.Add($">>Total Mês: R${TotalMes.ToString("N2")}");
                lstbxVendas.Items.Add("--------------------");
                TotalGeral += TotalMes;
                TotalMes = 0;
            }
            lstbxVendas.Items.Add($">>Total Geral: R${TotalGeral.ToString("N2")}");
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            lstbxVendas.Items.Clear();
        }
    }
}
