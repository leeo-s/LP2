﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pmatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            string[] Nomes = new string[5];
            int[] Tamanho = new int[5];

            for (var x = 0; x < 5; x++)
            {
                auxiliar = "";
                auxiliar = Interaction.InputBox("Digite o nome da pessoa:", "Pessoas");
                Nomes[x] = auxiliar;
            }

            for(var y=0; y<5; y++)
            {
                int i = 0;
                foreach (var j in Nomes[y])
                    if (j == ' ')
                        i++;
                Tamanho[y] = Nomes[y].Length - i;
            }

            for (var a = 0; a < 5; a++)
                lstbxNomes.Items.Add($"O nome {Nomes[a]} tem {Tamanho[a]} caracteres");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxNomes.Items.Clear();
        }
    }
}
