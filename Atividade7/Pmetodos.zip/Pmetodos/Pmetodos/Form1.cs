﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Texto copiado");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Texto colado");
        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(Application.OpenForms.OfType<frmExercicio2>().Count()>0)
            {
                MessageBox.Show("Formulario já existe!");
                Application.OpenForms["frmExercicio2"].Activate();
            }
            else
            {
                frmExercicio2 Obj2 = new frmExercicio2();
                Obj2.MdiParent = this;
                Obj2.WindowState = FormWindowState.Maximized;
                Obj2.Show();
            }
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio3>().Count() > 0)
            {
                MessageBox.Show("Formulario já existe!");
                Application.OpenForms["frmExercicio3"].Activate();
            }
            else
            {
                frmExercicio3 Obj3 = new frmExercicio3();
                Obj3.MdiParent = this;
                Obj3.WindowState = FormWindowState.Maximized;
                Obj3.Show();
            }
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio4>().Count() > 0)
            {
                MessageBox.Show("Formulario já existe!");
                Application.OpenForms["frmExercicio4"].Activate();
            }
            else
            {
                frmExercicio4 Obj4 = new frmExercicio4();
                Obj4.MdiParent = this;
                Obj4.WindowState = FormWindowState.Maximized;
                Obj4.Show();
            }
        }

        private void exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmExercicio5>().Count() > 0)
            {
                MessageBox.Show("Formulario já existe!");
                Application.OpenForms["frmExercicio5"].Activate();
            }
            else
            {
                frmExercicio5 Obj5 = new frmExercicio5();
                Obj5.MdiParent = this;
                Obj5.WindowState = FormWindowState.Maximized;
                Obj5.Show();
            }
        }
    }
}
