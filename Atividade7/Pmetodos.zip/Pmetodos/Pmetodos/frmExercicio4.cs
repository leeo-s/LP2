﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            richtxtFrase.Clear();
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            int contador = 0;

            for(var i=0; i<richtxtFrase.Text.Length; i++)
            {
                if(char.IsNumber(richtxtFrase.Text[i]))
                {
                    contador++;
                }
            }
            MessageBox.Show($"A quantidade de números no texto é de {contador} números!");
        }

        private void btnPosicao_Click(object sender, EventArgs e)
        {
            int contador = 0, posicao = 0;

            while(contador < richtxtFrase.Text.Length)
            {
                if(char.IsWhiteSpace(richtxtFrase.Text[contador]))
                {
                    posicao = contador + 1;
                    break;
                }
                contador++;
            }
            MessageBox.Show($"A posição do primeiro caracter em branco é a {posicao}ª posição!");
        }

        private void btnContaLetras_Click(object sender, EventArgs e)
        {
            int contador = 0;

            foreach(var c in richtxtFrase.Text)
            {
                if(char.IsLetter(c))
                {
                    contador++;
                }
            }
            MessageBox.Show($"A quantidade de letras no texto é de {contador} letras!");
        }
    }
}
