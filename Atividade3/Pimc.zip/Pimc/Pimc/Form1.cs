﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double Imc, Peso, Altura;

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(mskbxAltura.Text, out Altura))
            {
                MessageBox.Show("Altura inválida!");
                mskbxAltura.Focus();
            }

            if(Altura<=0)
            {
                MessageBox.Show("Altura não pode ser menor ou igual a zero!");
                mskbxAltura.Focus();
            }
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(mskbxPeso.Text, out Peso))
            {
                MessageBox.Show("Peso inválido!");
                mskbxPeso.Focus();
            }

            if(Peso<=0)
            {
                MessageBox.Show("Peso não pode ser menor ou igual a zero!");
                mskbxPeso.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
            txtImc.Clear();
            txtClassificacao.Clear();
            txtFaixa.Clear();
            txtObesidade.Clear();

            Imc = 0;
            Peso = 0;
            Altura = 0;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
                Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Imc = Peso / Math.Pow(Altura, 2);
            txtImc.Text = Imc.ToString("N2");

            if(Imc<=18.5)
            {
                txtFaixa.Text = "Menor que 18,5";
                txtClassificacao.Text = "Magreza";
                txtObesidade.Text = "O";
            }
            else if(Imc<=24.9)
            {
                txtFaixa.Text = "Entre 18,5 e 24,9";
                txtClassificacao.Text = "Normal";
                txtObesidade.Text = "O";
            }
            else if (Imc<=29.9)
            {
                txtFaixa.Text = "Entre 25,0 e 29,9";
                txtClassificacao.Text = "Sobrepeso";
                txtObesidade.Text = "1";
            }
            else if(Imc<=39.9)
            {
                txtFaixa.Text = "Entre 30,0 e 39,9";
                txtClassificacao.Text = "Obesidade";
                txtObesidade.Text = "2";
            }
            else
            {
                txtFaixa.Text = "Maior que 40,0";
                txtClassificacao.Text = "Obesidade Grave";
                txtObesidade.Text = "3";
            }
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}
